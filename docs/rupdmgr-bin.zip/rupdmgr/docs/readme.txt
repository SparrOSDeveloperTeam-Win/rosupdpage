========================================

  ReactOS Updater (Unofficial program)
  
  Created by SparrOSDeveloperTeam

========================================

How it's used: Set main web browser as
firefox or something like that and run
this program. It will take you to
ReactOS Update.

Commands:

  RUPDMGR.EXE